<?php //echo "<pre>"; print_R($pm_list); die(); ?>
<div class="right_col" role="main">
	<section>
		<div class="create-project">
			<div class="create">
				<p>Create Project</p>
				<?php echo $message; ?>
				<form role="form" method="post" action="" enctype="multipart/form-data">
					<div class="form-group">
						<input type="text" name="project_name" class="form-control" placeholder="PROJECT NAME" title="project name" required="required"/>
					</div>
					<div class="form-group">
						<input id="uploadFile" placeholder="Choose File" disabled="disabled" />
						<div class="fileUpload">
							<span>Add Logo</span>
							<input id="uploadBtn" type="file" name="image" class="upload btn btn-primary" />
						</div>
					</div>
					<div class="form-group bottom">
						<input type="submit" id="send" name="send" value="Go"/>
					</div>
				</form>
				<div class="verticalLine"></div>
			</div>
		</div>
		<div class="existing-project"> 
			<div class="existing">
				<p>Existing Project</p>
				<?php echo $message1; ?>
				<div id="no-more-tables">
					<table class="col-md-12 table-bordered table-condensed cf">
						<thead class="cf">
							<tr>
								<th>Logo</th>
								<th>project name</th>
								<th>Action</th>						
							</tr>
						</thead>
						<tbody>
						<?php
							$i = 1;
							if($project_details){
								foreach($project_details as $key => $value){
									$img = base_url().'project_uploads/'.$value['project_logo'];
									?>
									<tr>
										<td><a href="<?= base_url(); ?>wbs_list/index/<?php echo $value['project_id']; ?>/"><?php echo '<img src="'.$img.'" style="width:50px; " >'; ?></a></td>
										<td><?php echo $value['project_name']; ?></td>
										<td>
											<a data-toggle="modal" data-target="#myModal<?php echo $i; ?>" href="#" class="edit-existing">Add</a> 
											<a href="<?= base_url(); ?>add_project/edit_project_users/<?php echo $value['project_id']; ?>/" class="edit-existing">Update</a>
											<a href="<?= base_url();?>add_project/view_assigned_users/<?php echo $value['project_id']; ?>/" class="view-existing">View</a>
											<a onClick="return doconfirm();" href="<?= base_url();?>add_project/delete_projects/<?php echo $value['project_id']; ?>/" class="delete-existing">Delete</a>
										</td>
									</tr>
									<?php
									$i++;
								}
							}if($pm_assigned_details){
								foreach($pm_assigned_details as $key => $value){
									$img = base_url().'project_uploads/'.$value['project_logo'];
									?>
									<tr>
										<td><a href="<?= base_url(); ?>wbs_list/index/<?php echo $value['project_id']; ?>/"><?php echo '<img src="'.$img.'" style="width:50px; " >'; ?></a></td>
										<td><?php echo $value['project_name']; ?></td>
										<td>
											<a data-toggle="modal" data-target="#myModal<?php echo $i; ?>" href="#" class="edit-existing">Add</a> 
											<a href="<?= base_url(); ?>add_project/edit_project_users/<?php echo $value['project_id']; ?>/" class="edit-existing">Update</a>
											<a href="<?= base_url();?>add_project/view_assigned_users/<?php echo $value['project_id']; ?>/" class="view-existing">View</a>
											<a onClick="return doconfirm();" href="<?= base_url();?>add_project/delete_projects/<?php echo $value['project_id']; ?>/" class="delete-existing">Delete</a>
										</td>
									</tr>
									<?php
									$i++;
								}
							}else{
								?>
									<tr>
										<td colspan="3" style="color: red;">
											There is no Project.
										</td>
									</tr>
								<?php
							}
						?>
						</tbody>
					</table>
				</div>
				<div class="verticalLine"></div>
			</div>	  
		</div>  
	</section>
</div>
<?php
	$i = 1;
	foreach($project_details as $key => $value){
		$img = base_url().'project_uploads/'.$value['project_logo'];
		?>
		<div id="myModal<?php echo $i; ?>" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Add Users to Project</h4>
					</div>
					<form method="post" action="" name="form1<?php echo $i; ?>" id="form1<?php echo $i; ?>" enctype="multipart/form-data">
						<div class="modal-body">
							<input type="hidden" name="hidden_id" value="<?php echo $value['project_id']; ?>"/>
							<input id="uploadFile1" placeholder="Choose File" disabled="disabled" />
							<div class="fileUpload1">
								<span>Add Logo</span>
								<input id="uploadBtn1" type="file" name="image1" class="upload btn btn-primary" />
							</div>
							<div class="logoimage">
								<?php echo '<img src="'.$img.'" style="width:50px; " class="img-responsive">'; ?>
							</div>
							<input type="text" class="form-control" name="project_name1" value="<?php echo $value['project_name']; ?>"/>
							<select class="select2_multiple form-control" name="tm_list[]" multiple="multiple">
								<?php
									foreach($tm_list as $key => $tm_value){
										?>
										<option value="<?php echo $tm_value['user_id'];?>"><?php echo $tm_value['user_id'];?></option>
										<?php
									}
								?>
							</select>
						</div>
						<div class="modal-footer">
							<button type="submit" name="update_users" class="edit-existing">Submit</button>
							<button type="button" class="delete-existing" data-dismiss="modal">Close</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php
		$i++;
	} 
?>
<script>
	function doconfirm() {
		job=confirm("Are you sure to delete this user?");
		if(job!=true) {
			return false;
		}
	}
</script>